package edu.ourincheon.app2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        genBtn.setOnClickListener {
            val name = editText.text.toString()
            val a:MutableList<Int> = getLottoNumbersFromHash(name)

            button2.text = a[0].toString()
            button3.text = a[1].toString()
            button4.text = a[2].toString()
            button5.text = a[3].toString()
            button6.text = a[4].toString()
            button7.text = a[5].toString()
        }

        clearBtn.setOnClickListener {
            button2.text = "0"
            button3.text = "0"
            button4.text = "0"
            button5.text = "0"
            button6.text = "0"
            button7.text = "0"
        }

    }

    private fun getLottoNumbersFromHash(name:String) : MutableList<Int> {
        val list = mutableListOf<Int>()

        for (number in 1..45) {
            list.add(number)
        }
        list.shuffle(Random(name.hashCode().toLong()))

        return list.subList(0, 6)
    }
}
