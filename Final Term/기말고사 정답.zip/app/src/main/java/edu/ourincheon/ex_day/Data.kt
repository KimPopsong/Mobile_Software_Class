package edu.ourincheon.ex_day

class Data {
    val words: Array<String> = arrayOf("프래그먼트", "액티비티")
    val definitions: Array<String> = arrayOf(
        "프래그먼트(Fragment)는 하니콤 버전(API level 11)부터 추가된 기능이다." +
                "프래그먼트는 태블릿과 같이 넓은 화면을 갖는 " +
                "모바일 장치를 위한 메커니즘이다.",
        "액티비티(Activity)는 사용자 인터페이스 화면을 갖으며, " +
                "UI 관련 내용을 처리하는 컴포넌트이다.")
}
