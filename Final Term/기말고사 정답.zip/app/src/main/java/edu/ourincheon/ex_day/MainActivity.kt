package edu.ourincheon.ex_day

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), WordFragment.RadioButtonClicked {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textFragment =
            supportFragmentManager.findFragmentById(R.id.fragment2) as TextFragment
        textFragment.showDescription(0)
    }

    override fun describeWords(index: Int) {
        val textFragment =
            supportFragmentManager.findFragmentById(R.id.fragment2) as TextFragment
        textFragment.showDescription(index)
    }
}
