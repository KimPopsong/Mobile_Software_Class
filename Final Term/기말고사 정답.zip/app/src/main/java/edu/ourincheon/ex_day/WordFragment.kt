package edu.ourincheon.ex_day

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import androidx.fragment.app.Fragment

class WordFragment: Fragment(){

    var index:Int = 0
    var activityCallback:RadioButtonClicked? = null

    interface RadioButtonClicked {
        fun describeWords(index:Int)
    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        try {
            activityCallback = context as RadioButtonClicked
        } catch (e:ClassCastException) {
            throw ClassCastException(context?.toString() +
                    "must implement RadioButtonClicked")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        val rootView = inflater.inflate(R.layout.words_fragment, container, false)
        val word1:RadioButton = rootView.findViewById(R.id.wordRadioButton)
        val word2:RadioButton = rootView.findViewById(R.id.wordRadioButton2)

        word1.setOnClickListener {
            index = 0
            radioButtonClick()
        }
        word2.setOnClickListener {
            index = 1
            radioButtonClick()
        }
        return rootView
    }

    private fun radioButtonClick() {
        activityCallback?.describeWords(index)
    }
}