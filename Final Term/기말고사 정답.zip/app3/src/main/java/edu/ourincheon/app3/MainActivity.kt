package edu.ourincheon.app3

import android.os.Bundle
import android.widget.RatingBar.OnRatingBarChangeListener
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ratingBar.onRatingBarChangeListener =
            OnRatingBarChangeListener { ratingBar, rating, fromUser ->
                showMessage(rating)
            }

    }

    fun showMessage(rate:Float) {
        if (rate == 5f) {
            showToast("정말 멋진 강의였어")
        } else if (rate > 3 && rate <5) {
            showToast("나쁘진 않았어")
        } else if (rate < 3) {
            showToast("최악의 강의였어")
        }

    }

    fun showToast(msg:String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }
}
