package com.example.lab_1201801527

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnlis = btnListener()
        button.setOnClickListener(btnlis)
    }

    inner class btnListener : View.OnClickListener{
        override fun onClick(v: View?) {
            show()
        }
    }

    fun show(){
        var id = radioGroup.checkedRadioButtonId
        when(id){
            R.id.radioButton -> imageView.setImageResource(R.drawable.image0)
            R.id.radioButton2 -> imageView.setImageResource(R.drawable.image1)
            R.id.radioButton3 -> imageView.setImageResource(R.drawable.image2)
        }
    }
}