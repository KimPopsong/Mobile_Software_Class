package com.example.lab_2201801527

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Float.parseFloat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?)  {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_clear.setOnClickListener{
            editText.setText("")
        }

        button10.setOnClickListener {
            val temp = editText.text.toString()
            if (temp.isNotEmpty())
                tempConversion(temp) //temp 인자를 받아서 전과 동일하게 실행해준다
            //섭씨를 화씨로 바꿔주는 버튼에 체크가 돼있으면 그렇게 실행해주고 화씨를 섭씨로 바꿔주는 버튼에 체크가 돼있으면 그렇게 실행해준다.
            //마지막에는 예외처리까지 돼있다.
            else {
                Toast.makeText(applicationContext,"정확한 값을 입력하세요",Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun convertCelsiusToFahrenheit(celsius:Float){
        val f:Float = (celsius*9)/5+32
        var fahrenheit = String.format("%.lf",f)
        editText.setText("섭씨 : $celsius C --> 화씨 : $fahrenheit")
    }
    private fun convertFahrenheitToCelsius(fahrenheit:Float){
        var c:Float=(fahrenheit-32)*5/9
        var celsius = String.format("%.lf",c)
        editText.setText("화씨 : $fahrenheit F --> 섭씨 : $celsius")
    }
    private fun tempConversion(s:String){
        var value = 0f

        try{
            value=parseFloat(s)
            if(radioButton.isChecked)
                convertCelsiusToFahrenheit(value)
            else if (radioButton2.isChecked)
                convertFahrenheitToCelsius(value)
        } catch(e:NumberFormatException){
            e.printStackTrace()
        }
    }
}